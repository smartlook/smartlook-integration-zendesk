$(function() {
	var client = ZAFClient.init();
	client.invoke('resize', { width: '100%', height: '210px' });
	client.get('ticket.requester.id').then(
		function(data) {
			var userId = data['ticket.requester.id'];
			getUser(client, userId);
		}
	);
});

function getSessions(client, token, email) {
	var sessions = {
		url:'https://www-beta.smartlook.com/api/sessions.list',
		type:'POST',
		data: {
			apiKey: token,
			/*filters: {
				visitorEmail: email
			},*/
			sorters: {
				timeStart: -1
			}
		}
	};

	client.request(sessions).then(
		function(data) {
			showSessions();
			console.log(data);
		},
		function(response) {
			showError(response);
		}
	);
}

function getUser(client, id) {
	var settings = {
		url: '/api/v2/users/' + id + '.json',
		type:'GET',
		dataType: 'json',
	};

	client.request(settings).then(
		function(data) {
			showUser(data);
			client.context().then(function(context) {
  				console.log(context);
			});
			client.metadata().then(function(metadata) {
				console.log(metadata);
				getSessions(client, metadata.settings.token, data.user.email);
			});
		},
		function(response) {
			showError(response);
		}
	);
}

function showUser(data) {
	var userData = {
		'name': data.user.name,
		'email': data.user.email,
	};
	templateCompile(userData, "main-template");
}

function showSessions() {
	var sessionsData = {
		'sessions': {}
	};
	templateCompile(sessionsData, "main-template");
}

function showError(response) {
	var errorData = {
		'status': response.status,
		'statusText': response.statusText
	};
	templateCompile(errorData, "error-template");
}

function templateCompile(data, selector) {
	var source = $("#" + selector).html();
	var template = Handlebars.compile(source);
	var html = template(data);
	$("#content").html(html);
}